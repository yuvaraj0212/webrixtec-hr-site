// import React from "react";
// // import { useHistory } from "react-router-dom";

// // const history = useHistory();
// function index(props, auth) {
//   const handelClick = () => {
//     // auth();
//     props.history.push("/dashboard");
//   };
//   console.log(props);
//   return (
//     <>
//       <h1> pls Auth</h1>
//       <button onClick={handelClick}>login</button>
//     </>
//   );
// }

// export default index;
